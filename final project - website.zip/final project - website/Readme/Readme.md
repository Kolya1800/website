# Personal Website Project

My name is Kolya Cherepenin.

This File contains the source code for my personal website, which I developed as a final project. The website showcases my background, professional experience, personal activities, projects, and more.

## Features
- Multi-page responsive website with consistent navigation
- Pages include Home, About, Education, Activities, Projects, Gallery, and Contact
- Responsive design using Bootstrap framework
- Interactive image gallery with modal view
- Contact form for visitors to reach out

## Technologies Used
- HTML5
- CSS3
- Bootstrap 5
- JavaScript (for gallery modal)


## Usage
- Navigate through the website using the top navigation bar.
- View project details on the Projects page.
- Explore personal activities and gallery images.
- Use the contact form to send messages.



---
Kolya Cherepenin
